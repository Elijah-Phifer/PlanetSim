import Pkg

Pkg.add("Plots")
Pkg.add("OrdinaryDiffEq")
Pkg.add("ModelingToolkit")


